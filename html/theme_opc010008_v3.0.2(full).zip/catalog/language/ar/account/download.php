<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']   = 'ملفات التنزيل';

// Text
$_['text_account']    = 'الحساب';
$_['text_downloads']  = 'روابط التنزيل';
$_['text_empty']        = 'لم تقم بطلب أي ملف رقمي للتنزيل حتى الآن!';

// Column
$_['column_order_id']   = 'رقم الطلب';
$_['column_name']       = 'اسم الملف الرقمي';
$_['column_size']       = 'حجم الملف';
$_['column_date_added'] = 'تاريخ الطلب';