<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Text
$_['text_success'] = 'تم بدء جلسة API بنجاح !';

// Error
$_['error_key']  = 'تحذير: مفتاح API غير صحيح !';
$_['error_ip']   = 'تحذير: الاي بي الخاص بك %s غير مصرح له بالدخول الى واجهة API !';