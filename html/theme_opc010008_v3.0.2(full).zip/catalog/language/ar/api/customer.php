<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Text
$_['text_success']       = 'تم تعديل بيانات العميل بنجاح';

// Error
$_['error_permission']   = 'تحذير: انت لا تمتلك صلاحيات الدخول الى واجهة برمجة - API!';
$_['error_customer']     = 'يجب اختيار العميل !';
$_['error_firstname']    = 'الاسم الاول يجب ان يكون بين 1 و 32 حرف !';
$_['error_lastname']     = 'الاسم الاخير يجب ان يكون بين 1 و 32 حرف !';
$_['error_email']        = 'البريد الالكتروني غير صالح !';
$_['error_telephone']    = 'الرقم يجب ان يكون بين 3 و 32 رقم!';
$_['error_custom_field'] = '%s مطلوب !';
