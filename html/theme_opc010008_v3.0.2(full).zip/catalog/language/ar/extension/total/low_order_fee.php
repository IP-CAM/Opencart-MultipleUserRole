<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Text
$_['text_low_order_fee'] = 'رسوم مخفّضة';
