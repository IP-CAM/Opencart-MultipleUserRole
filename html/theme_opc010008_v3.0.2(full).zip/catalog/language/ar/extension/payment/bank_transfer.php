<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Text
$_['text_title']       = 'تـحـويـل بـنـكـي';
$_['text_instruction'] = 'تعليمات التـحـويـل البـنـكـي';
$_['text_description'] = 'الرجاء تحويل المبلغ إلى أحد حساباتنا البنكية.';
$_['text_payment']     = 'سوف تكتمل عملية الطلب حال انهاء التحويل البنكي وافادتنا بمعلومات التحويل.';