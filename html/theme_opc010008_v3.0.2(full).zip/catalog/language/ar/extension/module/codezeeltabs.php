<?php
// Heading 
$_['heading_title'] = "Best Products";

$_['tab_latest'] = 'Latest';
$_['tab_bestseller'] = 'Bestseller';
$_['tab_special'] = 'Special';

$_['text_no_products'] = 'No more products found!';
$_['text_view_more'] = 'View More Products';

// Text
$_['text_tax']      = 'Ex Tax:';