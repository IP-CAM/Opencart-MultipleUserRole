<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title'] = 'اختر المتجر';

// Text
$_['text_default']  = 'الافتراضي';
$_['text_store']    = 'الرجاء اختيار المتجر لزيارته.';