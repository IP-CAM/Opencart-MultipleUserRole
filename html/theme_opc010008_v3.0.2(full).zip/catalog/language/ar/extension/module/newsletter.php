<?php
// Heading
$_['heading_title']     = 'Newsletter';
$_['newsletter_description']     = 'You may unsubscribe at any moment. For that purpose, please find our contact info.';
$_['text_email']     = 'Email';
$_['text_placeholder']   = 'Enter Your Email Address';
$_['text_subscribe'] = 'OK';

// Email
$_['email_subject']       = 'Welcome';
$_['email_content']       = 'Thank you for Subscription.';




