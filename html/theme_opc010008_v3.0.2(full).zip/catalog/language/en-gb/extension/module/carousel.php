<?php
// Heading
$_['heading_title'] = 'Top Brands';