<?php
// Text
$_['text_all']  = 'Show All';
$_['text_home'] = 'Home';
$_['text_menu'] = 'Menu';
$_['text_blog'] = 'Blogs';