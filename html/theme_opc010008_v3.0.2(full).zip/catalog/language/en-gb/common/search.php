<?php
// Text
$_['text_search'] = 'Search Products Here';